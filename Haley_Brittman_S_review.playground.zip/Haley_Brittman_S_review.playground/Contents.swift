/*: - Copyright :  Bulldog Ventures Inc  ©  2020 */
import UIKit

/*:

- Variables

Create a variable called name and initialize it to the name of your favorite actor, singer, or sports celebrity */
let Actress = "Tara Strong"


/*:
- Displaying on the screen

Display the contents of name on the screen

 Change the value of name to your name*/
var name = "Haley Brittman"
print(name)
/*:
- Constants
 
Display the contents of name

Create a constant (let instead of var) called language and initialize it to "Swift"

Display the contents of the language constant on screen

Create 3 different constants and initialize them to hold integers of your choice. Name the constants a, b, and c

Create 3 constants that are doubles (they have decimal points) Initialize them with values of your choice. Name the constants d, e, and f*/
let language = "Swift"
print(language)

let a = 10
let b = 38
let c = 54

let d = 98.898
let e = 4099.000
let f = 244.65
/*:
- Operators

Create an assortment of statements using the constants that you created that will perform the following actions - then display the equation and the result on the screen.*/
var e1 = (a + b)
var e2 = (d - e)
var e3 = (b / c)
var e4 = (a + c)

/*:
- Add two constants
 
-                print("a + b = " ) + (a + b)

Addition sample with at least 4 constants

Subtraction sample

Division sample

Multiplication sample*/
let var1 = 5
let var2 = 2
let var3 = 10
let var4 = 7
print(var1 * var2 )
/*:
- If Statements
 
Use the following constants to solve the problems :*/
 
let temperature = 90
let raining = true
let time = "Morning"
var morning = true
var night = true
var afternoon = true


/*: Write a statement that tells someone to wear shorts if it is over 80 degrees, and jeans if it is less than 80 degrees. Check with the temperature constant

Check the raining constant and tell the user if they need an umbrella or not

Check the time constant and if it is morning tell the user to go to school, if it is afternoon tell the user to go home, and if it is night tell the user to go to bed*/
if (raining){
    print("You need a umbrella")
}
if (temperature > 80){
    print("Wear shorts")
}
else {
    print("Wear jeans")
}
if (morning){
    print("Go to school")
}
//This means if its nighttime it will tell the user to go to bed
if (night){
    print("Go to bed")
}
if (afternoon){
    print("Go home")
}



/*:
- Loops

Using a for loop print the numbers from 1 to 10 on screen

Using  a while loop print the numbers from 10 to 1 on screen*/
for excel in (1...10){
    print(excel)
}
/*:
- Collections

Create an array that holds five strings

Create a tuple that holds two strings

Using a loop, step through one of the collections you created and print all of the items to the screen*/
var myArray = [1, 2, 3, 4, 5]
var myTuple = (var1,var2,var3,var4)
print(myArray)
/*:
- Functions

Create a function that takes two doubles, multiplies them, and returns the result.

Call the function, save the result in the variable "answer". Pass it two of the constants you  creataed (a, b, c, d, e, or f)*/
func myForm (a: Int, b: Int) -> Int {
    return a - b
}
print ("Conclusion: \(myForm (a: 5, b: 5) )")
/*:
- Enums
 
Create an enum that holds the first name of everyone in your group

Create a switch statement based on the enum that will display the birthday of the
selected person

Test it by using your own name*/
enum people: CaseIterable {
    case Aaron
    case Yenny
    case Kennedy
}

/*:
- Structure
 
Create a structure called Name that holds a first, middle, and last name and prints them on screen in one line with spaces between them

Create an instance of the Name structure, pass it your name, and use the instance you created to print your  name to the screen*/
struct Nammmee {
    var firstName = "Eleanor"
    var middleName = "Lensey"
    var lastName = "Shellstrop"
}

let names = Nammmee()
print("My full name is (firstName.middleName.lastName)")


/*:
- Class
 
Create a class called Coffee that accepts size, caffineated,  cream,  and sugar then prints the order on screen

Create an instance of the class

Use the instance of the class and call the function*/
class Coffee {
    var size: String = "small"
    var caffineated: Bool = true
    var cream: Bool = true
    var sugar: Bool = true

    func order () {
        print("Your order is done")
    }
}
var food: Coffee

